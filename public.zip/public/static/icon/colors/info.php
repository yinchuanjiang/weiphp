<?php
return array (
		'cate' => '多彩图标',
		'author' => 'easyicon'
);					