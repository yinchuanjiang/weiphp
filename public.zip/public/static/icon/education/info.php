<?php
return array (
		'cate' => '教育',
		'author' => 'easyicon'
);					