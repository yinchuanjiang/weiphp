<?php
return array (
		'cate' => '餐饮食品',
		'author' => 'easyicon'
);					