<?php
return array (
		'cate' => '医疗',
		'author' => 'easyicon'
);					