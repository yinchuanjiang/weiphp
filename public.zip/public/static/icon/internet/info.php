<?php
return array (
		'cate' => '互联网',
		'author' => 'easyicon'
);					