<?php
return array (
		'cate' => '电影',
		'author' => 'easyicon'
);					