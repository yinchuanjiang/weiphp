<?php
return array (
		'cate' => '其他',
		'author' => 'easyicon'
);					