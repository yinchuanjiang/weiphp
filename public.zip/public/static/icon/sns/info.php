<?php
return array (
		'cate' => '社交网络',
		'author' => 'easyicon'
);					